# Import necessary libraries
from flask import Flask, render_template, request, send_file
from diffusers import StableDiffusionPipeline
import torch
import os

# Initialize Flask app
app = Flask(__name__)

# Load the pre-trained Stable Diffusion model
# Check if CUDA (GPU) is available for faster processing, else use CPU
device = "cuda" if torch.cuda.is_available() else "cpu"
model_id = "runwayml/stable-diffusion-v1-5"
pipe = StableDiffusionPipeline.from_pretrained(model_id).to(device)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_image():
    # Get the text description from the form
    text_description = request.form['description']

    # Generate the image from the text
    image = pipe(text_description).images[0]

    # Save the image to the static folder
    img_path = os.path.join('static', 'generated_image.png')
    image.save(img_path)

    # Return the image to the user
    return send_file(img_path, mimetype='image/png')

if __name__ == '__main__':
    # Start Flask app
    app.run(debug=True)
